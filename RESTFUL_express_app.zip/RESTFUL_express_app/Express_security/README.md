Partially implemented Sample Case Study(Learnign Management System)
